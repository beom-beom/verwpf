﻿using Oracle.ManagedDataAccess.Client;
using PresentPeopleVerbinding.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PresentPeopleVerbinding
{
    class Repository
    {
        private readonly string connectionString = @"Data Source=C:\sqlite\people";
        public ObservableCollection<People> LoadFromDatabase()
        {
            ObservableCollection<People> peopleList = new ObservableCollection<People>();

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteCommand command = new SQLiteCommand("SELECT * FROM people", connection))
                {
                    using (SQLiteDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = Convert.ToInt32(reader["id"]);
                            string name = reader["name"].ToString();
                            string gender = reader["gender"].ToString();
                            int age = Convert.ToInt32(reader["age"]);

                            People person = new People(id,name, gender, age.ToString());
                            
                            peopleList.Add(person);
                        }
                    }
                }
            }

            return peopleList;
        }
        public void SaveToDatabase(People people)
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteCommand command = new SQLiteCommand("INSERT INTO people (name, gender, age) VALUES (@name, @gender, @age)", connection))
                {
                    command.Parameters.AddWithValue("@name", people.Name);
                    command.Parameters.AddWithValue("@gender", people.Gender);
                    command.Parameters.AddWithValue("@age", people.Age);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void UpdateInDatabase(string name, string gender, int age, int id)
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteCommand command = new SQLiteCommand("UPDATE people SET name = @name, gender = @gender, age = @age WHERE id = @id", connection))
                {
                    command.Parameters.AddWithValue("@name", name);
                    command.Parameters.AddWithValue("@gender", gender);
                    command.Parameters.AddWithValue("@age", age);
                    command.Parameters.AddWithValue("@id", id);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void RemoveFromDatabase(int id)
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteCommand command = new SQLiteCommand("DELETE FROM people WHERE id = @id", connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
