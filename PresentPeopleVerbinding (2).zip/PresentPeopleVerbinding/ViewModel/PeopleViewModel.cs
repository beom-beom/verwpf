﻿using PresentPeopleVerbinding.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace PresentPeopleVerbinding.ViewModel
{
    class PeopleViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<People> listPeople= new ObservableCollection<People>();
        private Repository repository = new Repository();
        public ObservableCollection<People> ListPeople 
        {
            get { return listPeople; }
            set
            {
                listPeople = value;
                OnPropertyChanged(nameof(ListPeople));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public event NotifyCollectionChangedEventHandler CollectionChanged;
        private People selectedPeople;
        public People SelectedPeople
        {
            get { return selectedPeople; }
            set
            {
                selectedPeople = value;
                if (selectedPeople != null)
                {
                    TPeopleName = selectedPeople.Name;
                    TPeopleGender = selectedPeople.Gender;
                    TPeopleAge = selectedPeople.Age.ToString();
                }
                OnPropertyChanged(nameof(SelectedPeople));
            }
        }

        private string tpeopleName;
        public string TPeopleName { get { return tpeopleName; } set { tpeopleName = value; OnPropertyChanged(nameof(TPeopleName)); } }
        private string tpeopleGender;
        public string TPeopleGender { get { return tpeopleGender; } set { tpeopleGender = value; OnPropertyChanged(nameof(TPeopleGender)); } }
        private string tpeopleAge;
        public string TPeopleAge { get { return tpeopleAge; } set { tpeopleAge = value; OnPropertyChanged(nameof(TPeopleAge)); } }
        public ICommand AddCommand { get; private set; }
        public ICommand UpdateCommand { get; private set; }
        public ICommand RemoveCommand { get; private set; }


        public PeopleViewModel()
        {
            AddCommand = new RelayCommand(AddPeople, CanAddPeople);
            UpdateCommand = new RelayCommand(UpdatePeople, CanUpdatePeople);
            RemoveCommand = new RelayCommand(RemovePeople, CanRemovePeople);
            LoadDataFromDatabase();
        }
        private void LoadDataFromDatabase()
        {
            foreach (var person in repository.LoadFromDatabase())
            {
                ListPeople.Add(person);
            }
        }
        private bool CanAddPeople(object parameter)
        {
            return !string.IsNullOrWhiteSpace(TPeopleName) && !string.IsNullOrWhiteSpace(TPeopleGender) && !string.IsNullOrWhiteSpace(TPeopleAge);

        }
        public void AddPeople(object parameter)
        {
            People newPeople = new People(ListPeople.Count(),TPeopleName, TPeopleGender, TPeopleAge);
            ListPeople.Add(newPeople);
            repository.SaveToDatabase(newPeople);
        }
        public bool CanUpdatePeople(object parameter)
        {
            return SelectedPeople != null;
        }
        public void UpdatePeople(object parameter)
        {
            SelectedPeople.Update(TPeopleName, TPeopleGender, TPeopleAge);
            MessageBox.Show($"{ SelectedPeople.Id}");
            repository.UpdateInDatabase(TPeopleName, TPeopleGender, int.Parse(TPeopleAge), SelectedPeople.Id);
            People updatePeople = new People(SelectedPeople.Id, TPeopleName, TPeopleGender, TPeopleAge);
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Replace,SelectedPeople,updatePeople));
        }
        public bool CanRemovePeople(object parameter)
        {
            return SelectedPeople != null;
        }
        public void RemovePeople(object parameter)
        {
            repository.RemoveFromDatabase(SelectedPeople.Id);
            ListPeople.Remove(SelectedPeople);
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, SelectedPeople));
        }
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        protected virtual void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            CollectionChanged?.Invoke(this, e); 
        }
    }
}
