﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.Model
{
    class Student : People
    {
        private string mid;
        private string mname;

        private string mpassword;
        private string mmajor;
        public string Major { get { return mmajor; } set { mmajor = value; } }

        public readonly List<Lecture> myLecture;
        public Student(string name,string id,string password,string major)
        {
            mid = id;
            mname = name;
            mpassword = password;
            Name = mname;
            Id = mid;
            Password = mpassword;
            mmajor = major;
            role = Role.Student;
            myLecture = new List<Lecture>();
        }
        public void addmyLecture(Lecture lecture)
        {
            this.myLecture.Add(lecture);
        }
        public void cancelmyLecture(Lecture lecture)
        {
            this.myLecture.Remove(lecture);
        }
        public void getmyLecture()
        {
            foreach (Lecture lecture in myLecture)
            {
                Console.WriteLine(lecture);
            }
        }
      
    }
}
