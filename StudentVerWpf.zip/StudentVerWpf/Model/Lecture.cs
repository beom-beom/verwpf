﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.Model
{
    class Lecture
    {
        private string _name;
        public string Name { get { return _name; } set { _name = value; } }

        private Professor _professor;
        public Professor professor { get { return _professor; } set { _professor = value; } }
        private int _capacity;
        public int Capacity { get { return _capacity; } set { _capacity = value; } }

        public Lecture(string name, Professor professor, int capacity)
        {
            this.professor = professor;
            this.Name = name;
            this.Capacity = capacity;
        }
        public void plusCapacity()
        {
            this.Capacity += 1;
        }
        public void minusCapacity()
        {
            this.Capacity -= 1;
        }
        
    }
}
