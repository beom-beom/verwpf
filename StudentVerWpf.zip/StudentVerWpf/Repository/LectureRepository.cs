﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf
{
    class LectureRepository
    {
        private readonly List<Lecture> lectures = new List<Lecture>();

        public void Add(Lecture lecture)
        {
            if (!lectures.Any(existinglecture => existinglecture.Name == lecture.Name && existinglecture.professor == lecture.professor))
            {
                lectures.Add(lecture);
            }
            else
            {
                Console.WriteLine("이미 추가된 강의입니다.");
            }
        }

        public void Delete(Lecture lecture, Professor professor)
        {
            if (professor.Name == lecture.professor.Name)
            {
                lectures.Remove(lecture);
            }
        }
        public void Apply(string lecturename, Student student)
        {
            int i = lectures.FindIndex(lec => lec.Name == lecturename);
            bool applyimpossible = student.myLecture.Any(lecture => lecture.Name == lectures[i].Name);
            if (i != -1 && lectures[i].Capacity > 0 && applyimpossible == false)
            {
                student.addmyLecture(lectures[i]);
                lectures[i].minusCapacity();
            }
            else if (applyimpossible == true)
            {
                Console.WriteLine("이미 신청되었습니다.");
            }
            else if (lectures[i].Capacity == 0)
            {
                Console.WriteLine("수강 정원이 마감되었습니다.");
            }
        }
        public void Cancel(string lecturename, Student student)
        {
            int i = lectures.FindIndex(lec => lec.Name == lecturename);
            bool cancelpossible = student.myLecture.Any(lecture => lecture.Name == lectures[i].Name);
            if (i != -1 && cancelpossible == true)
            {
                student.cancelmyLecture(lectures[i]);
                lectures[i].plusCapacity();
            }
        }
        public void GetAll()
        {
            foreach (Lecture lecture in lectures)
            {
                Console.WriteLine(lecture);
            }
        }
        public void GetAll(string major)
        {
            foreach (Lecture lecture in lectures)
            {
                if (lecture.professor.Major == major)
                    Console.WriteLine(lecture);
            }
        }
        public void GetMyLecture(Professor professor)
        {
            foreach (Lecture lecture in lectures)
            {
                if (lecture.professor.Name == professor.Name)
                {
                    Console.WriteLine(lecture);
                }
            }
        }
    }
}
