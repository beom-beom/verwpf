﻿using System;
using System.Windows;
namespace StudentVerWpf
{
    public partial class MainWindow : Window
    {
        private Repository repository;
        public MainWindow()
        {
            InitializeComponent();
            repository = new Repository();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
