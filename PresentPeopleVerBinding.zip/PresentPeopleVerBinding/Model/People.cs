﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentPeopleVerBinding.Model
{
    class People : INotifyPropertyChanged
    {
        private static int mplusid=1;
        private int mid;
        public int Id { get { return mid; }  }
        private string mname;
        public string Name { get { return mname; } set { mname = value;  } }
        private string mgender;
        public string Gender { get { return mgender; } set { mgender = value; } }
        private int mage;

        public event PropertyChangedEventHandler PropertyChanged;

        public int Age { get { return mage; } set { mage = value; } }

       protected void OnPropertyChanged(object obj)
        {

        }
    }
}
