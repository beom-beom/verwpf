﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentPeopleVerbinding.Model
{
    class People : INotifyPropertyChanged
    {
        private static int mplusid = 1;
        private int mid;
        public int Id { get { return mid; } }
        private string mname;
        public string Name { get { return mname; } set { mname = value; } }
        private string mgender;
        public string Gender { get { return mgender; } set { mgender = value; } }
        private int mage;
        public int Age { get { return mage; } set { mage = value; } }
        public event PropertyChangedEventHandler PropertyChanged;
        
        public People(string name, string gender, string age)
        {
            mname = name;
            mgender = (gender.Contains("남") ? "남" : "여");
            mage = int.Parse(age);
        }

        public void PlusId()
        {
            mid=mplusid++;
        }
        public void Update(People people)
        {
            mname = people.mname;
            mage = people.mage;
            mgender = people.mgender;
        }
        protected void OnPropertyChanged(string propertyname)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
    }
}
