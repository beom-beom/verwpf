﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf
{
    class Repository : INotifyCollectionChanged
    {
        private static  ObservableCollection<People> peopleList = new ObservableCollection<People>();

        public event NotifyCollectionChangedEventHandler CollectionChanged;

        public void Add(People people)
        {
            if (!peopleList.Any(existingPerson => existingPerson.Id == people.Id))
            {
                peopleList.Add(people);
            }
            else
            {
                Console.WriteLine("이미 가입된 회원입니다.");
            }
        }
        public People Login(string Id, string password)
        {
            return peopleList.FirstOrDefault(person => person.Id == Id || person.Password == password);
        }
        public void Delete(People people)
        {
            if (peopleList.Contains(people))
            {
                peopleList.Remove(people);
            }
        }
        public void GetAll(Role role)
        {
            foreach (var person in peopleList)
            {
                Console.WriteLine(person);
            }
        }
        protected void RaiseCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            CollectionChanged?.Invoke(this, e);
        }
    }
}
