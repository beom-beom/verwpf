﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.ViewModel
{
    class RegisterViewModel : INotifyPropertyChanged
    {
        public readonly Repository repository = new Repository();
        private string tname;
        public string TName { get { return tname; } set { tname = value; onPropertyChanged(nameof(TName)); } }
        private string tmajor;
        public string TMajor { get { return tmajor; } set { tmajor = value;onPropertyChanged(nameof(TMajor)); } }
        private string tid;
        public string TId { get { return tid; } set { tid = value;onPropertyChanged(nameof(TId)); } }

        private string tpassword;
        public string TPassword { get { return tpassword; } set { tpassword = value; onPropertyChanged(nameof(TPassword)); } }

        public event PropertyChangedEventHandler PropertyChanged;
        public void Register()
        {
            People newpeople=new People(TName,T)
        }
        protected virtual void onPropertyChanged(string propertyname)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
       
    }
}
