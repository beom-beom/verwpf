﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.Model
{
    class Professor : People
    {
        private string mid;
        private string mname;

        private string mpassword;
        private string mmajor;
        public string Major { get { return mmajor; } set { mmajor = value; } }
        public Professor(string name, string id, string password,string major)
        {
            mid = id;
            mname = name;
            mpassword = password;
            Name = mname;
            mmajor = major;
            Id = mid;
            Password = mpassword;
            role = Role.Professor;
        }
    
    }

}
