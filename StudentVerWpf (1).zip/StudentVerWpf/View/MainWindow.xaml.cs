﻿using StudentVerWpf.Model;
using StudentVerWpf.View;
using StudentVerWpf.ViewModel;
using System;
using System.Windows;
using System.Windows.Navigation;

namespace StudentVerWpf
{
    public partial class MainWindow : Window
    {
        private LoginViewModel loginViewModel;
        public MainWindow()
        {
            InitializeComponent();
            loginViewModel = new LoginViewModel();
            this.DataContext = loginViewModel;   
        }
        private void Register_Click(object sender,RoutedEventArgs e)
        {
            StudentPage register = new StudentPage();
            register.ShowDialog();
        }
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (loginViewModel.CanLogin())
            {
                StudentPage page = new StudentPage();
                page.ShowDialog();
            }
            else
            {
                MessageBox.Show("아이디 또는 비밀번호가 일치하지 않습니다.");
            }
        }
    }
}
