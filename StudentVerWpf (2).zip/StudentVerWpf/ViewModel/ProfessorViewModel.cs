﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.ViewModel
{
    class ProfessorViewModel : INotifyPropertyChanged
    {
        private LectureRepository lectureRepository;
        private string mname;
        public string Name { get { return mname; } private set { mname = value; OnPropertyChanged(nameof(Name)); } }
        private string mmajor;
        public string Major { get { return mmajor; } set { mmajor = value; OnPropertyChanged(nameof(Major)); } }
        public ProfessorViewModel(Professor professor, LectureRepository lecturerepository)
        {
            mname = professor.Name;
            mmajor = professor.Major;
            lectureRepository = lecturerepository;
        }
        
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
