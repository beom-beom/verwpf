﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.ViewModel
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        
        private string mid;
        public string Id { get { return mid; } set { mid = value; OnPropertyChanged(nameof(Id)); } }
        private string mpassword;
        public string Password { get { return mpassword; } set { mpassword = value; OnPropertyChanged(nameof(Password)); } }
        public event PropertyChangedEventHandler PropertyChanged;
        public bool CanLogin()
        {
            People loginPeople = App.Repository.Login(Id, Password);
            return (loginPeople!=null) ? true : false;
        }
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
