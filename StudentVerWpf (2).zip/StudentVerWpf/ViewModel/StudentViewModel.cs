﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.ViewModel
{
    class StudentViewModel : INotifyPropertyChanged
    {
        private string mname;
        public string Name { get { return mname; }private set { mname = value; OnPropertyChanged(nameof(Name)); } }
        private List<Lecture> mylecture;
        public List<Lecture> MyLecture { get { return mylecture; } set {  MyLecture = value; OnPropertyChanged(nameof(MyLecture)); } }
        public StudentViewModel(Student student,LectureRepository lectureRepository)
        {
            mname = student.Name;
            mylecture = student.myLecture;
        }
        public void AddLecture(Lecture lecture)
        {
            MyLecture.Add(lecture);
        }
        public void RemoveLecture(Lecture lecture)
        {
            MyLecture.Remove(lecture);
        }
        

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
