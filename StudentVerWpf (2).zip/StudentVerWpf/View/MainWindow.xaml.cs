﻿using StudentVerWpf.Model;
using StudentVerWpf.View;
using StudentVerWpf.ViewModel;
using System;
using System.Windows;
using System.Windows.Navigation;

namespace StudentVerWpf
{
    public partial class MainWindow : Window
    { 

        private LoginViewModel loginViewModel;
        int xxx;
        public MainWindow()
        {
            InitializeComponent();
            loginViewModel = new LoginViewModel();
            this.DataContext = loginViewModel;
        }

        private void Register_Click(object sender,RoutedEventArgs e)
        {
            RegisterPage register = new RegisterPage();
            register.Show();
        }
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (loginViewModel.CanLogin())
            {
                StudentPage page = new StudentPage();
            }
            else
            {
                MessageBox.Show("아이디 또는 비밀번호가 일치하지 않습니다.");
            }
        }
    }
}
