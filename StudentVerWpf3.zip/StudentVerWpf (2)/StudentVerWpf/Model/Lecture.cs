﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.Model
{
    public class Lecture
    {
        private string mname;
        public string Name { get { return mname; } set { mname = value; } }

        private string mmajor;
        public string Major { get { return mmajor; } set { mmajor = value; } }
        private string mprofessorname;
        public string ProfessorName { get { return mprofessorname; } set { mprofessorname = value; } }
        private int mcapacity;
        public int Capacity { get { return mcapacity; } set { mcapacity = value; } }

        public Lecture(string name, string professorname,string major, int capacity)
        {
            mprofessorname = professorname;
            mname = name;
            mmajor = major;
            mcapacity = capacity;
        }
        public void plusCapacity()
        {
            this.Capacity += 1;
        }
        public void minusCapacity()
        {
            this.Capacity -= 1;
        }
        
    }
}
