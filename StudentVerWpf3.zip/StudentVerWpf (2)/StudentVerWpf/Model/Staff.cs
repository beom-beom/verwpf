﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.Model
{
    public class Staff : People
    {
        private string mid;
        private string mname;

        private string mpassword;
        public Staff(string name, string id, string password)
        {
            mid = id;
            mname = name;
            mpassword = password;
            Name = mname;
            Id = mid;
            Password = mpassword;
            role = Role.Staff;
        }
    }
}
