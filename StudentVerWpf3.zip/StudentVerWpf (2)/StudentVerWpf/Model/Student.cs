﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf.Model
{
    public class Student : People
    {
        private string mid;
        private string mname;
        private string mpassword;
        private string mmajor;
        public string Major { get { return mmajor; } set { mmajor = value; } }
        private ObservableCollection<Lecture> mylecture;

        public ObservableCollection<Lecture> myLecture { get { return mylecture; } set { mylecture = value; } }
        public Student(string name,string id,string password,string major)
        {
            mid = id;
            mname = name;
            mpassword = password;
            Name = mname;
            Id = mid;
            Password = mpassword;
            Major = mmajor;
            role = Role.Student;
            myLecture = new ObservableCollection<Lecture>();
        }
        public void AddmyLecture(Lecture lecture)
        {
            mylecture.Add(lecture);
        }
        public void CancelmyLecture(Lecture lecture)
        {
            mylecture.Remove(lecture);
        }
        public void getmyLecture()
        {
            foreach (Lecture lecture in myLecture)
            {
                Console.WriteLine(lecture);
            }
        }
      
    }
}
