﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StudentVerWpf.ViewModel
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        
        private string mid;
        public string TId { get { return mid; } set { mid = value; OnPropertyChanged(nameof(TId)); } }
        private string mpassword;
        public string TPassword { get { return mpassword; } set { mpassword = value; OnPropertyChanged(nameof(TPassword)); } }
        public event PropertyChangedEventHandler PropertyChanged;
        public People CanLogin()
        {
            return App.Repository.Login(TId, TPassword);
        }
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
