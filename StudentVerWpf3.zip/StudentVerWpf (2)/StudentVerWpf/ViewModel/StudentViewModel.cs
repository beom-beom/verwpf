﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace StudentVerWpf.ViewModel
{
     class StudentViewModel : INotifyPropertyChanged
    {
        private string tname;
        public string TName { get { return tname; }private set { tname = value; RaisePropertyChanged(nameof(TName)); } }
        private string tmajor;
        public string TMajor { get { return tmajor; } private set { tmajor = value; RaisePropertyChanged(nameof(TMajor)); } }
        private Role trole;
        public Role TRole { get { return trole; } set { trole = value; RaisePropertyChanged(nameof(TRole)); } }
        private Lecture selectlecture;
        public Lecture SelectLecture { get { return selectlecture; } set { selectlecture = value; RaisePropertyChanged(nameof(SelectLecture)); } }
        private ObservableCollection<Lecture> tlecture;
        public ObservableCollection<Lecture> TLecture { get { return tlecture; } set { tlecture = value; RaisePropertyChanged(nameof(TLecture)); } }
        private ObservableCollection<Lecture> mylecture;
        public ObservableCollection<Lecture> MyLecture { get { return mylecture; } set {  MyLecture = value; RaisePropertyChanged(nameof(MyLecture)); } }
        public ICommand AddCommand { get; private set; }
        public ICommand RemoveCommand { get; private set; }
        public StudentViewModel(Student student)
        {
            tname = student.Name;
            tmajor = student.Major;
            mylecture = student.myLecture;
            trole = Role.Student;
            AddCommand = new RelayCommand(AddLecture, CanDoingLecture);
            RemoveCommand = new RelayCommand(RemoveLecture, CanDoingLecture);
            tlecture = App.LectureRepository.GetAll(TMajor);
        }
        public bool CanDoingLecture(object parameter)
        {
            return SelectLecture!=null;
        }
        public void AddLecture(object parameter)
        {
            MyLecture.Add(SelectLecture);
        }
        public void RemoveLecture(object parameter)
        {
            MyLecture.Remove(SelectLecture);
        }
        
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
