﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace StudentVerWpf.ViewModel
{
    class RelayCommand : ICommand
    {
        private readonly Action<object> mexecute;
        private readonly Func<object, bool> mcanExecute;


        public RelayCommand(Action<object> execute, Func<object, bool> canExecute)
        {
            mexecute = execute;
            mcanExecute = canExecute;
        }
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter)
        {
            return mcanExecute(parameter);
        }

        public void Execute(object parameter)
        {
            mexecute(parameter);
        }
    }
}
