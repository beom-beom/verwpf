﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StudentVerWpf.ViewModel
{
    class RegisterViewModel : INotifyPropertyChanged
    {

        public List<Role> LstRole { get; set; } = new List<Role>();
        private string trole;
        public string TRole { get { return trole; } set { trole = value; RaisePropertyChanged(nameof(TRole)); } }

        private string tname;
        public string TName { get { return tname; } set { tname = value; RaisePropertyChanged(nameof(TName)); } }
        private string tmajor;
        public string TMajor { get { return tmajor; } set { tmajor = value;RaisePropertyChanged(nameof(TMajor)); } }
        private string tid;
        public string TId { get { return tid; } set { tid = value;RaisePropertyChanged(nameof(TId)); } }

        private string tpassword;
        public string TPassword { get { return tpassword; } set { tpassword = value; RaisePropertyChanged(nameof(TPassword)); } }

        public event PropertyChangedEventHandler PropertyChanged;

        public RegisterViewModel()
        {
        }
        public void Register()
        {
            if (TRole.Contains("교수")) {
                App.Repository.Add(new Professor(TName, TId, TPassword, TMajor));
            }
            else if(TRole.Contains("학생")){
                App.Repository.Add(new Student(TName, TId, TPassword, TMajor));
            }
            else
            {
                App.Repository.Add(new Staff(TName, TId, TPassword));
            }
        }
        protected virtual void RaisePropertyChanged(string propertyname)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
       
    }
}
