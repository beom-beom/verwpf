﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace StudentVerWpf.ViewModel
{
    class ProfessorViewModel : INotifyPropertyChanged
    {
        private string tname;
        public string TName { get { return tname; } private set { tname = value; RaisePropertyChanged(nameof(TName)); } }
        private string tmajor;
        public string TMajor { get { return tmajor; } set { tmajor = value; RaisePropertyChanged(nameof(TMajor)); } }
        private Role trole;
        public Role TRole { get { return trole; } set { trole = value; RaisePropertyChanged(nameof(TRole)); } }
        private string tlectureName;
        public string TLectureName { get { return tlectureName; } set { tlectureName = value; RaisePropertyChanged(nameof(TLectureName)); } }
        private int tcapacity;
        public int TCapacity { get { return tcapacity; } set { tcapacity = value; RaisePropertyChanged(nameof(TCapacity)); } }
        private Lecture selectlecture;
        public Lecture SelectLecture { get { return selectlecture; } set { selectlecture = value; RaisePropertyChanged(nameof(SelectLecture)); } }
        private ObservableCollection<Lecture> listLecture = new ObservableCollection<Lecture>();
        public ObservableCollection<Lecture> ListLecture
        {
            get { return listLecture; }
            set
            {
                listLecture = value;
                RaisePropertyChanged(nameof(ListLecture));
            }
        }
        public ICommand AddCommand { get; private set; }
        public ICommand RemoveCommand { get; private set; }

        public ProfessorViewModel(Professor professor)
        {
            tname = professor.Name;
            tmajor = professor.Major;
            trole = professor.role;
            AddCommand = new RelayCommand(AddLecture, CanAddLecture);
            RemoveCommand = new RelayCommand(RemoveLecture, CanRemoveLecture);

        }
        public bool CanAddLecture(object parameter)
        {
            return !string.IsNullOrWhiteSpace(TLectureName) && TCapacity != 0; 
        }
        public bool CanRemoveLecture(object parameter)
        {
            return SelectLecture != null;
        }
        public void AddLecture(object parameter)
        {
            listLecture.Add(new Lecture(TLectureName,TName,TMajor,TCapacity));
        }
        public void RemoveLecture(object parameter)
        {
            listLecture.Remove(SelectLecture);
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
