﻿using StudentVerWpf.Model;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;

namespace StudentVerWpf.View
{
    class StaffViewModel : INotifyPropertyChanged
    {
        private  ObservableCollection<People> peopleList = new ObservableCollection<People>();
        public  ObservableCollection<People> PeopleList { get { return peopleList; } set{ peopleList = value; RaisePropertyChanged(nameof(peopleList)); }  }
        private string mname;
        public string Name { get { return mname; } private set { mname = value; RaisePropertyChanged(nameof(Name)); } }
        private Role mrole;
        public Role Role { get { return mrole; } private set { mrole = value; RaisePropertyChanged(nameof(Role)); } }
        public event PropertyChangedEventHandler PropertyChanged;

        public StaffViewModel(Staff staff)
        {
            mname = staff.Name;
            mrole = staff.role;
            peopleList = App.Repository.getAll();
        }
        protected virtual void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}