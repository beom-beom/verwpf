﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentVerWpf
{
    public class LectureRepository 
    {
        private readonly ObservableCollection<Lecture> lectures = new ObservableCollection<Lecture>();


        public void Add(Lecture lecture)
        {
            if (!lectures.Any(existinglecture => existinglecture.Name == lecture.Name && existinglecture.ProfessorName == lecture.ProfessorName))
            {
                lectures.Add(lecture);
            }
            else
            {
                Console.WriteLine("이미 추가된 강의입니다.");
            }
        }

        public void Delete(Lecture lecture, Professor professor)
        {
            if (professor.Name == lecture.ProfessorName)
            {
                lectures.Remove(lecture);
            }
        }
        public void Apply(string lecturename, Student student)
        {
            int i = lectures.IndexOf(lectures.SingleOrDefault(lecture => lecture.Name == lecturename));
            bool applyimpossible = student.myLecture.Any(lecture => lecture.Name == lectures[i].Name);
            if (i != -1 && lectures[i].Capacity > 0 && applyimpossible == false)
            {
                student.AddmyLecture(lectures[i]);
                lectures[i].minusCapacity();
            }
            else if (applyimpossible == true)
            {
                Console.WriteLine("이미 신청되었습니다.");
            }
            else if (lectures[i].Capacity == 0)
            {
                Console.WriteLine("수강 정원이 마감되었습니다.");
            }
        }
        public void Cancel(string lecturename, Student student)
        {
            int i = lectures.IndexOf(lectures.SingleOrDefault(lecture => lecture.Name == lecturename));
            bool cancelpossible = student.myLecture.Any(lecture => lecture.Name == lectures[i].Name);
            if (i != -1 && cancelpossible == true)
            {
                student.CancelmyLecture(lectures[i]);
                lectures[i].plusCapacity();
            }
        }
        public ObservableCollection<Lecture> GetAll(string major)
        {
            return new ObservableCollection<Lecture>(lectures.Where(lecture => lecture.Major == major));
        }
    }
}
