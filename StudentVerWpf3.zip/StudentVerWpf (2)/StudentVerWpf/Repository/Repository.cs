﻿using StudentVerWpf.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StudentVerWpf
{
     public class Repository : INotifyCollectionChanged
    {
        private readonly ObservableCollection<People> peopleList = new ObservableCollection<People>();

        public event NotifyCollectionChangedEventHandler CollectionChanged;

        public void Add(People people)
        {
            if (!peopleList.Any(existingPerson => existingPerson.Id == people.Id))
            {
                peopleList.Add(people);
            }
            else
            {
                MessageBox.Show("이미 가입된 회원입니다");
            }
        }
        public People Login(string Id, string password)
        {
            return peopleList.FirstOrDefault(person => person.Id == Id && person.Password == password);
        }
        public void Delete(People people)
        {
            if (peopleList.Contains(people))
            {
                peopleList.Remove(people);
            }
        }
        public ObservableCollection<People> getAll()
        {
            return peopleList;
        }
        protected void RaiseCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            CollectionChanged?.Invoke(this, e);
        }
    }
}
