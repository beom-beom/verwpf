﻿    using StudentVerWpf.Model;
    using StudentVerWpf.View;
    using StudentVerWpf.ViewModel;
    using System;
    using System.Windows;
    using System.Windows.Navigation;

namespace StudentVerWpf
    {
        public partial class MainWindow : Window
        { 

            private LoginViewModel loginViewModel;
            public MainWindow()
            {
                InitializeComponent();
                loginViewModel = new LoginViewModel();
                this.DataContext = loginViewModel;
            }

            private void Register_Click(object sender,RoutedEventArgs e)
            {
                RegisterPage register = new RegisterPage();
                register.Show();
            }
            private void Login_Click(object sender, RoutedEventArgs e)
            {
                if (loginViewModel.CanLogin() is Student student)
                {
                    StudentPage studentPage = new StudentPage();
                    studentPage.SetStudent(student);
                    studentPage.Show();
                    Close();
                }
                else if (loginViewModel.CanLogin() is Professor professor)
                {
                    ProfessorPage professorPage = new ProfessorPage();
                    professorPage.SetProfessor(professor);
                    professorPage.Show();
                    Close();
                }
                else if (loginViewModel.CanLogin() is Staff staff)
                {
                    StaffPage staffPage = new StaffPage();
                    staffPage.SetStaff(staff);
                    staffPage.Show();
                    Close();
                }
                else
                {
                    MessageBox.Show("아이디 또는 비밀번호가 일치하지 않습니다.");
                }
            }
        }
    }
