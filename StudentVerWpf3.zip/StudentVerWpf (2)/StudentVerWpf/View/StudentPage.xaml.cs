﻿using StudentVerWpf.Model;
using StudentVerWpf.ViewModel;
using System.Windows;

namespace StudentVerWpf.View
{
    /// <summary>
    /// StudentPage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class StudentPage : Window
    {
        private StudentViewModel studentViewModel;

        public StudentPage()
        {
            InitializeComponent();
        }

        public void SetStudent(Student student)
        {
            studentViewModel = new StudentViewModel(student);
            DataContext = studentViewModel;
        }
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            Close();

        }
    }
}
